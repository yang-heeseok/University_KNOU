# -*- coding: utf-8 -*-
"""
Created on Sun Sep  7 12:39:33 2025

@author: USER
"""

print("Hello Python!")